/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./InputMask/index.ts"
/*!****************************!*\
  !*** ./InputMask/index.ts ***!
  \****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   InputMask: () => (/* binding */ InputMask)\n/* harmony export */ });\nclass InputMask {\n  // FIXED: Added comment to satisfy \"no-empty-function\" rule\n  constructor() {\n    // FIXED: Removed \": string\" because it is inferred from '=\"\"'\n    this._currentValue = \"\";\n    // Empty constructor\n  }\n  init(context, notifyOutputChanged, state, container) {\n    this._notifyOutputChanged = notifyOutputChanged;\n    // Create the input box\n    this._inputElement = document.createElement(\"input\");\n    this._inputElement.setAttribute(\"type\", \"text\");\n    this._inputElement.setAttribute(\"placeholder\", \"(555) 555-5555\");\n    this._inputElement.classList.add(\"mask-input\");\n    // Add event listener for typing\n    this._inputElement.addEventListener(\"input\", this.onInputChange.bind(this));\n    container.appendChild(this._inputElement);\n  }\n  onInputChange(event) {\n    var input = this._inputElement;\n    // 1. Strip everything that isn't a number\n    var rawValue = input.value.replace(/\\D/g, \"\");\n    // 2. Limit to 10 digits\n    if (rawValue.length > 10) {\n      rawValue = rawValue.substring(0, 10);\n    }\n    // 3. Format as (XXX) XXX-XXXX\n    var formattedValue = rawValue;\n    if (rawValue.length > 6) {\n      formattedValue = \"(\".concat(rawValue.substring(0, 3), \") \").concat(rawValue.substring(3, 6), \"-\").concat(rawValue.substring(6));\n    } else if (rawValue.length > 3) {\n      formattedValue = \"(\".concat(rawValue.substring(0, 3), \") \").concat(rawValue.substring(3));\n    } else if (rawValue.length > 0) {\n      formattedValue = \"(\".concat(rawValue);\n    }\n    // 4. Update the input box and the internal value\n    input.value = formattedValue;\n    this._currentValue = formattedValue;\n    // 5. Notify Dataverse\n    this._notifyOutputChanged();\n  }\n  updateView(context) {\n    // If data comes from the database, display it\n    if (context.parameters.maskedValue.raw) {\n      this._currentValue = context.parameters.maskedValue.raw;\n      this._inputElement.value = this._currentValue;\n    }\n  }\n  getOutputs() {\n    return {\n      maskedValue: this._currentValue\n    };\n  }\n  // FIXED: Added comment to satisfy \"no-empty-function\" rule\n  destroy() {\n    // Cleanup code\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./InputMask/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./InputMask/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('BalaControls.InputMask', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.InputMask);
} else {
	var BalaControls = BalaControls || {};
	BalaControls.InputMask = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.InputMask;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}